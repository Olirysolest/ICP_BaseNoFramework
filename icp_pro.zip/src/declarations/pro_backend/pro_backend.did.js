export const idlFactory = ({ IDL }) => {
  return IDL.Service({
    '_dajdupy' : IDL.Func([], [IDL.Text], []),
    'greet' : IDL.Func([IDL.Text], [IDL.Text], ['query']),
  });
};
export const init = ({ IDL }) => { return []; };
