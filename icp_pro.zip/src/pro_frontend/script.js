import { pro_backend } from "../declarations/pro_backend";


document.getElementById("Btn").addEventListener("click", async () =>
{
const name = document.getElementById("place");
const gr = await pro_backend._dajdupy();
document.getElementById("place").innerText = gr;
});

